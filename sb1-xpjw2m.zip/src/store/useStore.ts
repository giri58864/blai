import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User, Document } from '../types';

interface Store {
  user: User | null;
  documents: Document[];
  apiKey: string | null;
  setUser: (user: User | null) => void;
  setApiKey: (apiKey: string) => void;
  addDocument: (document: Document) => void;
  updateDocument: (id: string, updates: Partial<Document>) => void;
}

export const useStore = create<Store>()(
  persist(
    (set) => ({
      user: null,
      documents: [],
      apiKey: null,
      setUser: (user) => set({ user }),
      setApiKey: (apiKey) => set({ apiKey }),
      addDocument: (document) =>
        set((state) => ({ documents: [...state.documents, document] })),
      updateDocument: (id, updates) =>
        set((state) => ({
          documents: state.documents.map((doc) =>
            doc.id === id ? { ...doc, ...updates } : doc
          ),
        })),
    }),
    {
      name: 'legal-assistant-storage',
    }
  )
);