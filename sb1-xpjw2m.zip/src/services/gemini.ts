import { GoogleGenerativeAI } from '@google/generative-ai';
import { parseGeminiResponse } from '../utils/parseAnalysis';
import { DocumentAnalysis } from '../types';
import { useStore } from '../store/useStore';

export async function analyzeLegalDocument(content: string): Promise<DocumentAnalysis> {
  const { apiKey } = useStore.getState();
  if (!apiKey) {
    throw new Error('API key not found');
  }

  const genAI = new GoogleGenerativeAI(apiKey);
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

  const prompt = `Analyze the following legal document and provide a structured response in this format:

Clauses:
- [Clause Type]|[Clause Content]|[Risk Level: low/medium/high]

Risk Flags:
- [Clause Reference]|[Reason for Flag]|[Severity: low/medium/high]

Expiration Date: [Date if found]

Document content:
${content}`;

  try {
    const result = await model.generateContent(prompt);
    const response = await result.response;
    return parseGeminiResponse(response.text());
  } catch (error) {
    console.error('Error analyzing document:', error);
    throw new Error('Failed to analyze document');
  }
}