export interface User {
  id: string;
  email: string;
  role: 'user' | 'advisor';
  name: string;
}

export interface Document {
  id: string;
  title: string;
  uploadedBy: string;
  uploadDate: Date;
  status: 'pending' | 'reviewed' | 'flagged';
  expirationDate?: Date;
  content: string;
  analysis?: DocumentAnalysis;
  reviewedBy?: string;
  reviewDate?: Date;
}

export interface DocumentAnalysis {
  clauses: Clause[];
  riskFlags: RiskFlag[];
  expirationDate?: Date;
}

export interface Clause {
  type: string;
  content: string;
  riskLevel: 'low' | 'medium' | 'high';
}

export interface RiskFlag {
  clause: string;
  reason: string;
  severity: 'low' | 'medium' | 'high';
}