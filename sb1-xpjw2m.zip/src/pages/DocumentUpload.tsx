import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, Loader } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { analyzeLegalDocument } from '../services/gemini';
import toast from 'react-hot-toast';
import { Button } from '../components/Button';

export default function DocumentUpload() {
  const { user, addDocument } = useStore();
  const navigate = useNavigate();
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file || !user) return;

    setIsAnalyzing(true);
    try {
      const content = await file.text();
      const analysis = await analyzeLegalDocument(content);

      const newDocument = {
        id: crypto.randomUUID(),
        title: file.name,
        uploadedBy: user.id,
        uploadDate: new Date(),
        status: 'pending',
        content,
        analysis,
      };

      addDocument(newDocument);
      toast.success('Document uploaded and analyzed successfully');
      navigate(`/document/${newDocument.id}`);
    } catch (error) {
      toast.error('Error processing document. Please try again.');
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  }, [user, addDocument, navigate]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/plain': ['.txt'],
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
    },
    maxFiles: 1,
    disabled: isAnalyzing,
  });

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Upload Document</h1>
      
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer
          ${isDragActive ? 'border-indigo-500 bg-indigo-50' : 'border-gray-300 hover:border-indigo-500'}
          ${isAnalyzing ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        <input {...getInputProps()} />
        {isAnalyzing ? (
          <>
            <Loader className="mx-auto h-12 w-12 text-indigo-500 animate-spin" />
            <p className="mt-2 text-sm text-gray-600">Analyzing document...</p>
          </>
        ) : (
          <>
            <Upload className="mx-auto h-12 w-12 text-gray-400" />
            <p className="mt-2 text-sm text-gray-600">
              {isDragActive
                ? "Drop the file here"
                : "Drag 'n' drop a document, or click to select"}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              Supports PDF, DOC, DOCX, and TXT files
            </p>
          </>
        )}
      </div>

      <div className="text-center">
        <Button
          variant="secondary"
          onClick={() => navigate('/')}
          disabled={isAnalyzing}
        >
          Cancel
        </Button>
      </div>
    </div>
  );
}