import React from 'react';
import { Bell, Calendar } from 'lucide-react';
import { useStore } from '../store/useStore';
import { Button } from '../components/Button';
import { Link } from 'react-router-dom';

export default function Alerts() {
  const { documents } = useStore();

  const expiringDocs = documents.filter(doc => {
    if (!doc.expirationDate) return false;
    const daysUntilExpiration = Math.ceil(
      (new Date(doc.expirationDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
    );
    return daysUntilExpiration <= 30;
  });

  const flaggedDocs = documents.filter(doc => doc.status === 'flagged');

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Alerts & Notifications</h1>

      <div className="grid grid-cols-1 gap-6">
        {expiringDocs.length > 0 && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center space-x-2 mb-4">
              <Calendar className="h-6 w-6 text-yellow-500" />
              <h2 className="text-xl font-semibold">Expiring Documents</h2>
            </div>
            <div className="space-y-4">
              {expiringDocs.map(doc => (
                <div key={doc.id} className="flex items-center justify-between p-4 bg-yellow-50 rounded-lg">
                  <div>
                    <h3 className="font-medium">{doc.title}</h3>
                    <p className="text-sm text-gray-600">
                      Expires on {new Date(doc.expirationDate!).toLocaleDateString()}
                    </p>
                  </div>
                  <Link to={`/document/${doc.id}`}>
                    <Button variant="secondary" size="sm">View Document</Button>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        )}

        {flaggedDocs.length > 0 && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center space-x-2 mb-4">
              <Bell className="h-6 w-6 text-red-500" />
              <h2 className="text-xl font-semibold">Documents Flagged for Review</h2>
            </div>
            <div className="space-y-4">
              {flaggedDocs.map(doc => (
                <div key={doc.id} className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
                  <div>
                    <h3 className="font-medium">{doc.title}</h3>
                    <p className="text-sm text-gray-600">
                      Uploaded on {new Date(doc.uploadDate).toLocaleDateString()}
                    </p>
                  </div>
                  <Link to={`/document/${doc.id}`}>
                    <Button variant="secondary" size="sm">View Document</Button>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        )}

        {expiringDocs.length === 0 && flaggedDocs.length === 0 && (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm border border-gray-200">
            <Bell className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-lg font-medium text-gray-900">No alerts</h3>
            <p className="mt-1 text-sm text-gray-500">
              You're all caught up! No documents require immediate attention.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}