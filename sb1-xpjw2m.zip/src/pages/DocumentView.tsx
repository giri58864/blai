import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { AlertTriangle, Clock, CheckCircle, FileText, AlertCircle, Tag } from 'lucide-react';
import { useStore } from '../store/useStore';
import { Button } from '../components/Button';
import { Clause, RiskFlag } from '../types';

export default function DocumentView() {
  const { id } = useParams();
  const navigate = useNavigate(); // Fixed: Using useNavigate hook correctly
  const { documents, updateDocument, user } = useStore();
  const document = documents.find(doc => doc.id === id);
  const [selectedClause, setSelectedClause] = useState<Clause | null>(null);

  if (!document) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900">Document not found</h2>
        <Button
          variant="secondary"
          className="mt-4"
          onClick={() => navigate('/')}
        >
          Return to Dashboard
        </Button>
      </div>
    );
  }

  const handleStatusUpdate = (status: 'reviewed' | 'flagged') => {
    updateDocument(document.id, { 
      status,
      reviewedBy: user?.id,
      reviewDate: new Date()
    });
  };

  const getRiskLevelColor = (level: 'low' | 'medium' | 'high') => {
    switch (level) {
      case 'high': return 'text-red-600 bg-red-50 border-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-100';
      case 'low': return 'text-green-600 bg-green-50 border-green-100';
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Document Header */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <div className="flex justify-between items-center">
          <div className="space-y-1">
            <h1 className="text-3xl font-bold text-gray-900">{document.title}</h1>
            <div className="flex items-center space-x-4 text-sm text-gray-500">
              <span className="flex items-center">
                <FileText className="h-4 w-4 mr-1" />
                Uploaded {new Date(document.uploadDate).toLocaleDateString()}
              </span>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                ${document.status === 'flagged' ? 'bg-red-100 text-red-800' :
                  document.status === 'reviewed' ? 'bg-green-100 text-green-800' :
                  'bg-yellow-100 text-yellow-800'}`}>
                {document.status.charAt(0).toUpperCase() + document.status.slice(1)}
              </span>
            </div>
          </div>
          <div className="flex space-x-3">
            <Button
              variant="secondary"
              onClick={() => handleStatusUpdate('reviewed')}
              disabled={document.status === 'reviewed'}
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Mark as Reviewed
            </Button>
            <Button
              variant="danger"
              onClick={() => handleStatusUpdate('flagged')}
              disabled={document.status === 'flagged'}
            >
              <AlertTriangle className="h-4 w-4 mr-2" />
              Flag for Review
            </Button>
          </div>
        </div>
      </div>

      {/* Document Analysis */}
      {document.analysis && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Clauses Panel */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <Tag className="h-5 w-5 mr-2" />
                Identified Clauses
              </h2>
              <div className="space-y-3">
                {document.analysis.clauses.map((clause, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedClause(clause)}
                    className={`w-full text-left p-3 rounded-lg border transition-colors
                      ${selectedClause === clause ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200 hover:bg-gray-50'}
                      ${getRiskLevelColor(clause.riskLevel)}`}
                  >
                    <div className="font-medium">{clause.type}</div>
                    <div className="text-sm mt-1 line-clamp-2">{clause.content}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Risk Flags */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <AlertCircle className="h-5 w-5 mr-2" />
                Risk Analysis
              </h2>
              <div className="space-y-3">
                {document.analysis.riskFlags.map((flag, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg ${getRiskLevelColor(flag.severity)}`}
                  >
                    <p className="font-medium">{flag.clause}</p>
                    <p className="text-sm mt-1">{flag.reason}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Document Content and Details */}
          <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="mb-6">
              <h2 className="text-xl font-semibold mb-4">Document Details</h2>
              {document.expirationDate && (
                <div className="flex items-center text-gray-700 mb-4 p-3 bg-yellow-50 rounded-lg">
                  <Clock className="h-5 w-5 mr-2" />
                  <span>Expires: {new Date(document.expirationDate).toLocaleDateString()}</span>
                </div>
              )}
            </div>

            {selectedClause ? (
              <div className="prose max-w-none">
                <h3 className="text-lg font-medium mb-2">{selectedClause.type}</h3>
                <div className={`p-4 rounded-lg mb-4 ${getRiskLevelColor(selectedClause.riskLevel)}`}>
                  {selectedClause.content}
                </div>
                <button
                  onClick={() => setSelectedClause(null)}
                  className="text-sm text-indigo-600 hover:text-indigo-500"
                >
                  View full document
                </button>
              </div>
            ) : (
              <div className="prose max-w-none">
                <pre className="text-sm bg-gray-50 p-4 rounded-lg overflow-auto max-h-[600px]">
                  {document.content}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}