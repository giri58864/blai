import React, { useState } from 'react';
import { Input } from './Input';
import { Button } from './Button';
import { Scale } from 'lucide-react';

interface ApiKeySetupProps {
  onSubmit: (apiKey: string) => void;
}

export function ApiKeySetup({ onSubmit }: ApiKeySetupProps) {
  const [apiKey, setApiKey] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(apiKey);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <Scale className="mx-auto h-12 w-12 text-indigo-600" />
          <h2 className="mt-6 text-3xl font-extrabold text-gray-900">
            Set up your API Key
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            To use the Legal Document Assistant, you need to provide your Google Gemini API key
          </p>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <Input
            label="Google Gemini API Key"
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            required
            placeholder="Enter your API key"
          />

          <Button type="submit" className="w-full" disabled={!apiKey}>
            Save API Key
          </Button>

          <p className="text-xs text-gray-500 text-center">
            Your API key will be stored securely in your browser's local storage
          </p>
        </form>
      </div>
    </div>
  );
}