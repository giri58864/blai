import React from 'react';
import { Navigate } from 'react-router-dom';
import { useStore } from '../store/useStore';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiresAdvisor?: boolean;
}

export function ProtectedRoute({ children, requiresAdvisor = false }: ProtectedRouteProps) {
  const { user } = useStore();

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (requiresAdvisor && user.role !== 'advisor') {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}