import React from 'react';
import { Link } from 'react-router-dom';
import { Scale, Bell, Upload, LogOut } from 'lucide-react';
import { useStore } from '../store/useStore';

export default function Navbar() {
  const { user, setUser } = useStore();

  const handleLogout = () => {
    setUser(null);
  };

  return (
    <nav className="bg-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Scale className="h-8 w-8 text-indigo-600" />
            <span className="font-bold text-xl">LegalAI Assistant</span>
          </Link>
          
          {user && (
            <div className="flex items-center space-x-6">
              <Link to="/upload" className="flex items-center space-x-1 text-gray-600 hover:text-indigo-600">
                <Upload className="h-5 w-5" />
                <span>Upload</span>
              </Link>
              <Link to="/alerts" className="flex items-center space-x-1 text-gray-600 hover:text-indigo-600">
                <Bell className="h-5 w-5" />
                <span>Alerts</span>
              </Link>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-1 text-gray-600 hover:text-indigo-600"
              >
                <LogOut className="h-5 w-5" />
                <span>Logout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}