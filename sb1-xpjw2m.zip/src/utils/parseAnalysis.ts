import { DocumentAnalysis, Clause, RiskFlag } from '../types';

export function parseGeminiResponse(response: string): DocumentAnalysis {
  try {
    // Extract clauses section
    const clausesMatch = response.match(/Clauses:([\s\S]*?)(?=Risk Flags:|$)/i);
    const clauses: Clause[] = (clausesMatch?.[1]?.match(/- ([^\n]+)/g) || []).map(clause => {
      const [type, content, risk] = clause.substring(2).split('|').map(s => s.trim());
      return {
        type,
        content,
        riskLevel: (risk?.toLowerCase() || 'low') as 'low' | 'medium' | 'high'
      };
    });

    // Extract risk flags section
    const riskFlagsMatch = response.match(/Risk Flags:([\s\S]*?)(?=Expiration Date:|$)/i);
    const riskFlags: RiskFlag[] = (riskFlagsMatch?.[1]?.match(/- ([^\n]+)/g) || []).map(flag => {
      const [clause, reason, severity] = flag.substring(2).split('|').map(s => s.trim());
      return {
        clause,
        reason,
        severity: (severity?.toLowerCase() || 'low') as 'low' | 'medium' | 'high'
      };
    });

    // Extract expiration date
    const expirationMatch = response.match(/Expiration Date:\s*([^\n]+)/i);
    const expirationDate = expirationMatch ? new Date(expirationMatch[1]) : undefined;

    return {
      clauses,
      riskFlags,
      expirationDate
    };
  } catch (error) {
    console.error('Error parsing Gemini response:', error);
    return {
      clauses: [],
      riskFlags: [],
    };
  }
}